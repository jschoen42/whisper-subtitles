Dieses W�rterbuch basiert auf dem igerman98 Ispell-W�rterbuch, zu finden
unter https://www.j3e.de/ispell/igerman98/.

Das W�rterbuch und alle enthaltenen Wortlisten sind lizenziert unter der
GNU GPL, Version 2 und 3.

Autor: Bjoern Jacke <bjoern@j3e.de>
